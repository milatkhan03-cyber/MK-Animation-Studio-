# R8/ProGuard rules for release builds.
# Add project-specific keep rules here when reflection, JNI, or serialization requires them.
-keepattributes *Annotation*,InnerClasses,EnclosingMethod
