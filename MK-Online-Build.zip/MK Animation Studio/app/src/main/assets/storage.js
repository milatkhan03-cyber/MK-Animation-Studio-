const MKStorage = {
    KEY: "mk_animation_studio_data",

    getAll() {
        try {
            return JSON.parse(
                localStorage.getItem(this.KEY)
            ) || {
                projects: [],
                stories: [],
                characters: [],
                settings: {}
            };
        } catch (error) {
            return {
                projects: [],
                stories: [],
                characters: [],
                settings: {}
            };
        }
    },

    saveAll(data) {
        try {
            localStorage.setItem(
                this.KEY,
                JSON.stringify(data)
            );
            return true;
        } catch (error) {
            console.error("Save failed:", error);
            return false;
        }
    },

    save(type, item) {
        const data = this.getAll();

        if (!Array.isArray(data[type])) {
            data[type] = [];
        }

        const record = {
            id: item.id || (
                Date.now().toString() +
                Math.random().toString(16).slice(2)
            ),
            createdAt: item.createdAt || new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            ...item
        };

        const index = data[type].findIndex(
            x => x.id === record.id
        );

        if (index >= 0) {
            data[type][index] = record;
        } else {
            data[type].push(record);
        }

        return this.saveAll(data) ? record : null;
    },

    get(type) {
        const data = this.getAll();
        return data[type] || [];
    },

    delete(type, id) {
        const data = this.getAll();

        if (!Array.isArray(data[type])) {
            return false;
        }

        data[type] = data[type].filter(
            item => item.id !== id
        );

        return this.saveAll(data);
    },

    search(type, keyword) {
        const items = this.get(type);
        const query = String(keyword).toLowerCase();

        return items.filter(item =>
            JSON.stringify(item).toLowerCase().includes(query)
        );
    },

    exportBackup() {
        const data = this.getAll();
        const blob = new Blob(
            [JSON.stringify(data, null, 2)],
            { type: "application/json" }
        );

        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");

        link.href = url;
        link.download = "MK-Animation-Studio-Backup.json";
        link.click();

        URL.revokeObjectURL(url);
    },

    clearAll() {
        localStorage.removeItem(this.KEY);
    }
};

window.MKStorage = MKStorage;