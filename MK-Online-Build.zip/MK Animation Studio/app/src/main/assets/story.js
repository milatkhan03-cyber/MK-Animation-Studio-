const MKStory = {

    createStory(title, idea, genre = "Action Fantasy") {
        const story = {
            id: Date.now().toString(),
            title: title || "Untitled Story",
            idea: idea || "",
            genre: genre,
            episodes: [],
            createdAt: new Date().toISOString()
        };

        const saved = MKStorage.save("stories", story);

        return saved || story;
    },

    createEpisode(storyId, title, summary) {
        const stories = MKStorage.get("stories");

        const story = stories.find(
            item => item.id === storyId
        );

        if (!story) {
            return {
                success: false,
                message: "Story not found."
            };
        }

        const episode = {
            id: Date.now().toString(),
            title: title || "New Episode",
            summary: summary || "",
            scenes: [],
            createdAt: new Date().toISOString()
        };

        story.episodes.push(episode);

        const saved = MKStorage.save("stories", story);

        return {
            success: !!saved,
            episode: episode
        };
    },

    addScene(storyId, episodeId, scene) {
        const stories = MKStorage.get("stories");

        const story = stories.find(
            item => item.id === storyId
        );

        if (!story) return false;

        const episode = story.episodes.find(
            item => item.id === episodeId
        );

        if (!episode) return false;

        const newScene = {
            id: Date.now().toString(),
            title: scene.title || "New Scene",
            location: scene.location || "",
            description: scene.description || "",
            dialogue: scene.dialogue || "",
            camera: scene.camera || "",
            mood: scene.mood || "",
            createdAt: new Date().toISOString()
        };

        episode.scenes.push(newScene);

        return !!MKStorage.save("stories", story);
    },

    getStories() {
        return MKStorage.get("stories");
    },

    getStory(storyId) {
        return this.getStories().find(
            story => story.id === storyId
        ) || null;
    },

    deleteStory(storyId) {
        return MKStorage.delete("stories", storyId);
    },

    exportStory(storyId) {
        const story = this.getStory(storyId);

        if (!story) return null;

        return JSON.stringify(story, null, 2);
    }
};

window.MKStory = MKStory;