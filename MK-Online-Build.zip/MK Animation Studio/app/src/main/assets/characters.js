const MKCharacters = {

    defaultCharacters: [
        {
            id: "mk",
            name: "MK",
            age: 17,
            role: "Main Character",
            group: "13th Hunter",
            locked: true
        },
        {
            id: "sana",
            name: "Sana",
            age: 18,
            role: "Hunter",
            group: "13th Hunter",
            locked: true
        },
        {
            id: "imran",
            name: "Imran Khan",
            role: "Group Leader",
            group: "13th Hunter",
            locked: true
        },
        {
            id: "zain",
            name: "Zain",
            role: "Hunter",
            group: "13th Hunter"
        },
        {
            id: "kamran",
            name: "Kamran",
            role: "Hunter",
            group: "13th Hunter"
        },
        {
            id: "siraj",
            name: "Siraj Khan",
            role: "Hunter",
            group: "13th Hunter"
        },
        {
            id: "zoro",
            name: "Zoro",
            role: "Hunter",
            group: "13th Hunter"
        },
        {
            id: "shaheen",
            name: "Shaheen",
            role: "Hunter",
            group: "13th Hunter"
        },
        {
            id: "hunter-08",
            name: "Hunter 08",
            role: "Hunter",
            group: "13th Hunter"
        },
        {
            id: "hunter-09",
            name: "Hunter 09",
            role: "Hunter",
            group: "13th Hunter"
        },
        {
            id: "hunter-10",
            name: "Hunter 10",
            role: "Hunter",
            group: "13th Hunter"
        },
        {
            id: "hunter-11",
            name: "Hunter 11",
            role: "Hunter",
            group: "13th Hunter"
        },
        {
            id: "hunter-12",
            name: "Hunter 12",
            role: "Hunter",
            group: "13th Hunter"
        }
    ],

    initialize() {
        const existing = MKStorage.get("characters");

        if (existing.length === 0) {
            this.defaultCharacters.forEach(character => {
                MKStorage.save("characters", character);
            });
        }

        return MKStorage.get("characters");
    },

    getAll() {
        return MKStorage.get("characters");
    },

    getById(id) {
        return this.getAll().find(
            character => character.id === id
        ) || null;
    },

    add(character) {
        if (!character.name || !character.name.trim()) {
            return {
                success: false,
                message: "Character name is required."
            };
        }

        const newCharacter = {
            id: "character-" + Date.now(),
            name: character.name.trim(),
            age: character.age || "",
            role: character.role || "Hunter",
            power: character.power || "",
            personality: character.personality || "",
            appearance: character.appearance || "",
            backstory: character.backstory || "",
            group: character.group || "13th Hunter",
            locked: false
        };

        const saved = MKStorage.save(
            "characters",
            newCharacter
        );

        return {
            success: !!saved,
            character: saved
        };
    },

    update(id, changes) {
        const character = this.getById(id);

        if (!character) return false;

        if (character.locked) {
            return false;
        }

        const updated = {
            ...character,
            ...changes,
            id: character.id
        };

        return !!MKStorage.save("characters", updated);
    },

    delete(id) {
        const character = this.getById(id);

        if (!character || character.locked) {
            return false;
        }

        return MKStorage.delete("characters", id);
    },

    getHunterCount() {
        return this.getAll().filter(
            character => character.group === "13th Hunter"
        ).length;
    }
};

window.MKCharacters = MKCharacters;