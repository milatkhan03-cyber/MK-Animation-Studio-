const MKAgents = {

    main: {
        name: "MK Main Agent",
        role: "Master AI Coordinator",
        description: "Coordinates all studio agents and manages creative projects."
    },

    list: [
        {
            id: "assistant",
            name: "Smart Assistant",
            icon: "🤖",
            role: "General Studio Assistant"
        },
        {
            id: "story",
            name: "Story Agent",
            icon: "📖",
            role: "Anime Story and Episode Writer"
        },
        {
            id: "character",
            name: "Character Agent",
            icon: "🧑",
            role: "Character Design and Development"
        },
        {
            id: "image",
            name: "Image Agent",
            icon: "🎨",
            role: "Image Prompt Creator"
        },
        {
            id: "video",
            name: "Video Agent",
            icon: "🎬",
            role: "Video Scene Planner"
        },
        {
            id: "voice",
            name: "Voice Agent",
            icon: "🎙️",
            role: "Dialogue and Voice Planner"
        },
        {
            id: "director",
            name: "Director Agent",
            icon: "🎥",
            role: "Anime Direction and Cinematography"
        },
        {
            id: "creator",
            name: "Auto Creator Agent",
            icon: "⚡",
            role: "Coordinates Complete Production Plans"
        }
    ],

    getAll() {
        return this.list;
    },

    getAgent(id) {
        return this.list.find(agent => agent.id === id) || null;
    },

    getMainAgent() {
        return this.main;
    },

    createTask(agentId, instruction) {
        const agent = this.getAgent(agentId);

        if (!agent) {
            return {
                success: false,
                message: "Agent not found."
            };
        }

        return {
            success: true,
            agent: agent.name,
            role: agent.role,
            instruction: String(instruction || "").trim(),
            status: "Planning",
            createdAt: new Date().toISOString()
        };
    },

    createProductionPlan(projectName, idea) {
        return {
            project: projectName || "Untitled Project",
            idea: idea || "",
            coordinator: this.main.name,
            workflow: [
                "Story development",
                "Character development",
                "Scene and image planning",
                "Video scene planning",
                "Voice and dialogue planning",
                "Director review",
                "Final production plan"
            ],
            status: "Ready for planning",
            createdAt: new Date().toISOString()
        };
    }
};

window.MKAgents = MKAgents;